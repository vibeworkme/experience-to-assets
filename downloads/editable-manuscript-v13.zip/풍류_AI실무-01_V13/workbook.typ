#let T = json("workbook-tokens.json")
#let D = json("typeset/workbook.json")
#let M = json("book.json")
#let ink = rgb(T.ink)
#let muted = rgb(T.muted)
#let rule = rgb(T.rule)
#let paper = rgb(T.paper)
#import "visuals.typ": render-visual
#import "illustrated.typ": render-example, illustrated-opener
#set document(title: M.title + " · V13 일러스트 실무판", author: M.author)
#set page(width: 210mm, height: 170mm, margin: 0mm, fill: paper, header: none, footer: none)
#set text(font: "Wanted Sans", size: 11pt, fill: ink, lang: "ko", tracking: -0.005em)
#set par(justify: false, leading: 8.723pt, spacing: 0pt, first-line-indent: 0em)
#set heading(numbering: none)
#show heading: set block(above: 0pt, below: 0pt)
#show heading: it => it.body

#let words(s) = {
  for (i, word) in s.split(" ").enumerate() {
    if i > 0 { text(" ") }
    if word.len() < 19 { box(word) } else { word }
  }
}

#let rich(parts, color: none) = {
  for item in parts {
    if item.kind == "strong" { strong(words(item.text)) }
    else if item.kind == "link" { link(item.url, text(fill: if color == none { rgb("#006B82") } else { color }, underline(words(item.text)))) }
    else { words(item.text) }
  }
}

#let at(x, y, w, h, body, name: "frame") = context {
  let measured = measure(block(width: w, body)).height
  if measured > h + 0.1mm { panic(name + " overflow: " + str(calc.round(measured / 1mm, digits: 1)) + "mm > " + str(h / 1mm)) }
  place(top + left, dx: x, dy: y, block(width: w, body))
}

#let pictogram(kind, color, size: 24mm) = {
  let drawing = if kind == "folder" {
    "<path d='M7 20H26L32 26H57V52H7Z'/><path d='M7 20V13H26L32 20H53V26'/>"
  } else if kind == "chat" {
    "<path d='M9 11H55V43H31L18 54V43H9Z'/><path d='M18 22H46M18 31H40'/>"
  } else if kind == "workspace" {
    "<rect x='6' y='9' width='52' height='37' rx='2'/><path d='M6 20H58M22 20V46M25 55H49M37 46V55'/>"
  } else if kind == "cycle" {
    "<path d='M14 23A21 21 0 0 1 49 16L54 23M54 23V10M54 23H41M50 41A21 21 0 0 1 15 48L10 41M10 41V54M10 41H23'/>"
  } else if kind == "search" {
    "<circle cx='27' cy='27' r='17'/><path d='M40 40L56 56M19 23H35M19 31H30'/>"
  } else {
    "<circle cx='32' cy='32' r='24'/><path d='M18 32L28 42L47 22'/>"
  }
  image(bytes("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><g fill='none' stroke='" + color.to-hex() + "' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'>" + drawing + "</g></svg>"), width: size)
}

#let render-table(rows, c) = {
  set text(size: 10pt)
  set par(leading: 6pt, spacing: 0pt)
  let n = rows.first().len()
  let widths = if n == 2 { (24%, 76%) } else { (30%, 31%, 39%) }
  table(columns: widths, inset: (x: 5pt, y: 4.5pt),
    stroke: (x, y) => (bottom: if y == 0 { 0.7pt + c } else { 0.3pt + rule }),
    fill: (x, y) => if y == 0 { c.transparentize(91%) } else { none },
    ..rows.enumerate().map(((i, row)) => row.map(cell => {
      if i == 0 { text(weight: "bold", fill: c, rich(cell)) } else { rich(cell) }
    })).flatten())
}

#let content(blocks, c) = {
  for b in blocks {
    if b.kind == "p" { block(above: 0pt, below: 3mm, rich(b.text, color: c)) }
    else if b.kind == "list" {
      for item in b.items {
        block(above: 0pt, below: 3mm, grid(columns: (3mm, 1fr), column-gutter: 1mm,
          box(baseline: 0.3em, circle(radius: 1.2pt, fill: c)), rich(item, color: c)))
      }
    } else if b.kind == "table" { block(above: 1mm, below: 4mm, render-table(b.rows, c)) }
    else if b.kind == "callout" {
      block(width: 100%, above: 0pt, below: 4mm, inset: 4mm,
        fill: c.transparentize(94%), stroke: (left: 1.5pt + c), {
          set text(size: 10.5pt)
          set par(leading: 7pt, spacing: 0pt)
          block(below: 2mm, text(size: 10pt, weight: "bold", fill: c, rich(b.title)))
          content(b.blocks, c)
        })
    }
  }
}

#let panel(p, c) = {
  block(below: 3mm, text(size: 12pt, weight: "bold", fill: c, p.title))
  content(p.blocks, c)
}

#let header(title, ch, appendix: false, front: false) = {
  let c = rgb(T.chapters.at(ch).color)
  at(16mm, 10mm, 178mm, 5mm, {
    text(size: 8.5pt, weight: "bold", fill: c, if front { "WORKBOOK GUIDE" } else if appendix { "SOURCES & NOTES" } else { "CHAPTER 0" + str(ch + 1) })
    h(3mm)
    text(size: 8.5pt, fill: muted, if front { M.title } else if appendix { "자료와 편집 범위" } else { D.chapters.at(ch).title })
  })
  at(16mm, 20mm, 178mm, 20mm,
    text(font: "Paperlogy 7", size: 23pt, weight: "bold", title), name: "page title")
  place(top + left, dy: 45mm, rect(width: 2mm, height: 33mm, fill: c, stroke: none))
}

#let footer(c) = {
  at(16mm, 160mm, 150mm, 5mm, link(M.website, text(size: 8pt, fill: muted, M.website)))
  place(top + right, dx: -16mm, dy: 160mm,
    context text(font: "Geist Mono", size: 8.5pt, fill: c, str(counter(page).get().first())))
}

#let flow-area(p, c, ch, hub: false) = {
  let first = p.panels.first()
  let rows = first.blocks.first().rows.slice(1)
  at(16mm, 43mm, 178mm, 48mm, {
    text(size: 10pt, fill: muted, first.title)
    v(4mm)
    block(width: 178mm, {
      place(top + left, dx: 16mm, dy: 8mm, line(length: 146mm, stroke: (paint: c.transparentize(30%), thickness: 0.7pt, dash: "dotted")))
      grid(columns: (1fr,) * rows.len(), column-gutter: 4mm,
        ..rows.enumerate().map(((i, row)) => align(center, {
          let name = row.first().first().text
          let shape = if name.contains("자료") or name == "선택" or name == "어디서 출발하나" { "folder" }
            else if name == "요청" or name == "질문" or name == "대화" or name == "왜 만드는가" { "chat" }
            else if name == "초안" or name == "작업실" or name == "역할" or name == "무엇을 받나" { "workspace" }
            else if name == "반복" or name == "지침" { "cycle" }
            else if name == "검토" or name == "근거" or name == "인용" { "search" }
            else { "check" }
          circle(radius: 8mm, fill: paper, stroke: 0.9pt + c,
            align(center + horizon, pictogram(shape, c, size: 9mm)))
          v(2.5mm)
          text(size: 11pt, weight: "bold", fill: c, rich(row.first()))
          v(2mm)
          text(size: 10.2pt, rich(row.last()))
        })))
    })
  }, name: p.title + " diagram")
  let rest = p.panels.slice(1)
  let w = (178mm - 10mm * (rest.len() - 1)) / rest.len()
  for (i, part) in rest.enumerate() {
    at(16mm + i * (w + 10mm), 100mm, w, 51mm, panel(part, c), name: p.title + " " + part.title)
  }
}

#let worksheet(p, c) = {
  for (i, f) in p.panels.slice(0, 4).enumerate() {
    let x = 16mm + calc.rem(i, 2) * 94mm
    let y = 43mm + calc.floor(i / 2) * 45mm
    at(x, y, 84mm, 16mm, {
      text(size: 12pt, weight: "bold", fill: c, f.title)
      v(2mm)
      set text(size: 9.5pt, fill: muted)
      content(f.blocks, c)
    }, name: p.title + " field " + str(i))
    for k in range(3) {
      place(top + left, dx: x, dy: y + 20mm + k * 8mm, line(length: 84mm, stroke: 0.45pt + rule))
    }
  }
  at(16mm, 140mm, 178mm, 12mm, {
    let checks = p.panels.last()
    grid(columns: (22mm, 1fr, 1fr, 1fr), column-gutter: 4mm,
      text(size: 9.5pt, weight: "bold", fill: c, checks.title),
      ..checks.blocks.first().items.map(item => {
        set text(size: 9.5pt)
        grid(columns: (3mm, 1fr), column-gutter: 1.5mm,
          box(baseline: 0.1em, rect(width: 2.5mm, height: 2.5mm, stroke: 0.6pt + c)), rich(item))
      }))
  }, name: p.title + " checks")
}

#let body-page(p, ch, appendix: false, front: false, target: none) = page({
  let c = rgb(T.chapters.at(ch).color)
  header([#heading(level: 2, p.title)#if target != none { label(target) }], ch, appendix: appendix, front: front)
  if p.layout in ("materials", "brief", "poster", "social") {
    render-example(p, c, (at: at, content: content, rich: rich, panel: panel, ink: ink, muted: muted, rule: rule, paper: paper))
  } else if p.layout in ("transform", "prompt-map", "workspace-map", "feedback-loop", "evidence-map", "edit-reveal") {
    render-visual(p, c, (at: at, content: content, rich: rich, ink: ink, muted: muted, rule: rule, paper: paper))
  } else if p.layout == "flow" or p.layout == "hub" { flow-area(p, c, ch, hub: p.layout == "hub") }
  else if p.layout == "worksheet" { worksheet(p, c) }
  else if p.layout == "table" {
    at(16mm, 43mm, 178mm, 108mm, {
      content(p.lead, c)
      panel(p.panels.first(), c)
      let rest = p.panels.slice(1)
      if rest.len() > 0 {
        v(2mm)
        grid(columns: (1fr,) * rest.len(), column-gutter: 10mm,
          ..rest.map(part => block(panel(part, c))))
      }
    }, name: p.title)
  } else {
    let n = p.panels.len()
    let w = (178mm - 10mm * (n - 1)) / n
    for (i, part) in p.panels.enumerate() {
      at(16mm + i * (w + 10mm), 43mm, w, 108mm, panel(part, c), name: p.title + " " + part.title)
    }
  }
  footer(c)
  box(width: 1pt, height: 1pt)
})

#let opener(ch) = page(fill: rgb(T.chapters.at(ch).color), {
  let token = T.chapters.at(ch)
  set text(fill: white)
  at(18mm, 15mm, 174mm, 8mm, text(font: "Geist Mono", size: 10pt, "CHAPTER 0" + str(ch + 1)))
  at(18mm, 42mm, 130mm, 39mm, text(font: "Paperlogy 7", size: 67pt, weight: "bold", token.word))
  place(top + right, dx: -20mm, dy: 42mm, pictogram(token.icon, white, size: 35mm))
  at(18mm, 94mm, 174mm, 15mm,
    text(font: "Paperlogy 7", size: 22pt, [#heading(level: 1, D.chapters.at(ch).title)#label("ch-" + str(ch + 1))]))
  at(18mm, 114mm, 174mm, 10mm, text(size: 11pt, D.chapters.at(ch).promise))
  at(18mm, 137mm, 174mm, 14mm,
    grid(columns: (1fr, 1fr, 1fr), column-gutter: 10mm,
      ..D.chapters.at(ch).goals.enumerate().map(((i, g)) => {
        text(font: "Geist Mono", size: 8pt, "0" + str(i + 1))
        v(2mm)
        text(size: 10pt, g)
      })))
  place(top + right, dx: -16mm, dy: 160mm,
    context text(font: "Geist Mono", size: 8.5pt, str(counter(page).get().first())))
  box(width: 1pt, height: 1pt)
})

#page({
  place(top + left, image("assets/cover-openbook-v03.png", width: 210mm, height: 170mm, fit: "cover"))
  place(top + center, dy: 11mm, text(size: 8pt, fill: rgb("#253E4D"), tracking: 0.06em, "풍류 AI실무 시리즈   -01"))
  place(top + center, dy: 24mm, text(font: "Paperlogy 6", size: 45pt, weight: "semibold", tracking: -0.025em, fill: rgb("#253E4D"), "풍류 AI 실무"))
  place(top + center, dy: 45mm, text(size: 10.5pt, fill: rgb("#253E4D"), M.subtitle))
  place(top + center, dy: 54mm, text(size: 8.5pt, fill: rgb("#253E4D"), M.author + " 지음"))
  place(bottom + left, dx: 18mm, dy: -8mm, link(M.website, text(size: 8.5pt, fill: rgb("#253E4D"), M.website)))
  box(width: 1pt, height: 1pt)
})

#page({
  at(18mm, 19mm, 174mm, 10mm, text(font: "Geist Mono", size: 9pt, fill: rgb("#C64C32"), "PUNGRYU AI WORKBOOK   /   01 OF 03"))
  at(18mm, 40mm, 174mm, 20mm, text(font: "Paperlogy 7", size: 33pt, M.title))
  at(18mm, 66mm, 174mm, 12mm, text(size: 16pt, M.subtitle))
  at(18mm, 100mm, 120mm, 23mm, {
    text(size: 12pt, weight: "bold", "내 자료에서 시작해, 내 판단으로 완성한다.")
    v(4mm)
    text(size: 10.5pt, fill: muted, "일러스트 실무판 · V13 · 2026-10-17")
  })
  at(18mm, 139mm, 174mm, 15mm, {
    text(size: 10.5pt, M.author + " 지음")
    v(2mm)
    link(M.website, text(size: 10pt, fill: rgb("#006B82"), M.website))
  })
  box(width: 1pt, height: 1pt)
})

#body-page(D.front.pages.first() + (layout: "flow"), 0, front: true)

#page({
  header("차례", 0, front: true)
  context {
    for (i, ch) in D.chapters.enumerate() {
      let dest = label("ch-" + str(i + 1))
      let hd = query(dest).first()
      let c = rgb(T.chapters.at(i).color)
      at(16mm, 43mm + i * 17mm, 178mm, 15mm, link(dest, {
        grid(columns: (15mm, 1fr, 14mm), column-gutter: 3mm,
          text(font: "Geist Mono", size: 19pt, fill: c, "0" + str(i + 1)),
          {
            text(size: 13pt, weight: "bold", ch.title)
            v(2mm)
            text(size: 9.5pt, fill: muted, ch.promise)
          },
          align(right, text(font: "Geist Mono", size: 11pt, str(counter(page).at(hd.location()).first())))
        )
      }), name: "toc " + ch.title)
    }
  }
  footer(rgb("#C64C32"))
  box(width: 1pt, height: 1pt)
})

#for (ch, chapter) in D.chapters.enumerate() {
  illustrated-opener(ch, (at: at, content: content, rich: rich, footer: footer, ink: ink, muted: muted, rule: rule, paper: paper, T: T, D: D, M: M))
  for p in chapter.pages { body-page(p, ch) }
}
#for (i, p) in D.sources.pages.enumerate() { body-page(p, 5, appendix: true, target: "source-" + str(i)) }

#page({
  at(18mm, 87mm, 174mm, 65mm, {
    line(length: 28mm, stroke: 0.8pt + rgb("#C64C32"))
    v(4mm)
    text(font: "Paperlogy 7", size: 18pt, M.title)
    v(4mm)
    set text(size: 10pt, fill: muted)
    block(below: 2mm, "지은이 박희용 · 강의 녹취 재구성 및 보충 실습")
    block(below: 2mm, "V13 일러스트 실무판 · 2026-10-17 · 시리즈 01 / 03")
    block(below: 2mm, "판형 210 × 170 mm · Wanted Sans / Paperlogy / Geist Mono")
    block(below: 2mm, "표지·장면: AI 생성 이미지 · 도해와 예제 글자: 편집·조판")
    block(below: 2mm, "V12를 보존하고 별도 제작 · 국악 장면 일러스트와 문서·홍보물 시안 추가")
    link(M.website, text(fill: rgb("#006B82"), M.website))
  })
  box(width: 1pt, height: 1pt)
})
