# 자료와 편집 범위

## 강의 자료와 이번 판본의 범위

Google Drive의 '2610_풍류AI/녹음' 폴더에 있던 텍스트 녹취록 6개를 바탕으로 만든 복습용 편집본이다. 원자료 헤더의 강의자는 박희용이다. 원음과 대조한 전사본은 아니며 3회 과정 전체를 담은 완결 교재도 아니다.

### 원자료 목록
| 자료 | 녹취 헤더의 일시 | 길이 |
| --- | --- | --- |
| 1.txt | 2026-10-07 10:40 | 11분 59초 |
| 2.txt | 2026-10-12 10:00 | 55분 00초 |
| 3.txt | 2026-10-12 11:10 | 41분 18초 |
| 4.txt | 2026-10-12 12:00 | 49분 07초 |
| 5.txt | 2026-10-12 14:05 | 45분 30초 |
| 6.txt | 2026-10-12 15:00 | 55분 56초 |

### 편집 원칙
V12는 V11을 보존하고 문서 변환·요청문 해부·작업실 구조·검토 순환·근거 연결·수정 비교의 시각화 6면을 추가했다. 요청문·가상 공연·오류 초안·수정표·완성 예시와 도해는 편집자가 구성한 보충 실습이며 강의자의 직접 인용이나 실제 현장 성과가 아니다. 서비스 조건의 대조 기준일은 2026년 10월 17일이다.

## 서비스 도움말과 실습자료

### ChatGPT와 Gemini
- [ChatGPT 프로젝트·지침·메모리](https://help.openai.com/en/articles/10169521-projects-in-chatgpt)
- [ChatGPT 예약 작업](https://help.openai.com/en/articles/10291617-scheduled-tasks-in-chatgpt)
- [Gems의 스킬 전환 일정](https://support.google.com/gemini/answer/18560919?hl=ko)
- [Gem 만들기](https://support.google.com/gemini/answer/15235603?hl=ko)
- [스킬 만들기·관리](https://support.google.com/gemini/answer/17094296?co=GENIE.Platform%3DDesktop&hl=ko)
- [Gemini 채팅의 예약된 작업](https://support.google.com/gemini/answer/16316416?hl=ko)
- [Gemini 작업의 일정](https://support.google.com/gemini/answer/17094710?co=GENIE.Platform%3DDesktop&hl=ko)

### 노트북과 실습자료
- [Gemini Notebook 사용 설정·명칭](https://knowledge.workspace.google.com/admin/generative-ai/gemini-notebook/turn-gemini-notebook-on-or-off-for-users)
- [노트북 만들기](https://support.google.com/gemininotebook/answer/16206563?hl=ko)
- [소스 가져오기](https://support.google.com/gemininotebook/answer/16215270?co=GENIE.Platform%3DDesktop&hl=ko)
- [채팅·소스 인용](https://support.google.com/gemininotebook/answer/16179559?hl=ko)
- [메모 만들기·저장](https://support.google.com/gemininotebook/answer/16262519?hl=ko)

실습자료 묶음의 사실표, 편집 메모, 요청문, 오류 초안, 수정표와 완성 문서를 복사해 사용할 수 있다. 자신의 공연에 적용할 때는 가상 설정부터 확정 자료로 교체한다. 조작 안내는 설명용이며 독자 계정에서 실행한 기록은 아니다.
