from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import pymupdf


ROOT = Path(__file__).resolve().parent
MM = 72 / 25.4


def normalized(value: str) -> str:
    return "".join(char for char in value if char.isalnum())


def plain(parts: list[dict]) -> str:
    return "".join(part["text"] for part in parts)


def block_text(blocks: list[dict], *, diagram: bool = False) -> list[str]:
    result = []
    for block in blocks:
        kind = block["kind"]
        if kind == "p":
            result.append(plain(block["text"]))
        elif kind == "list":
            result.extend(plain(item) for item in block["items"])
        elif kind == "callout":
            result.append(plain(block["title"]))
            result.extend(block_text(block["blocks"]))
        elif kind == "table":
            rows = block["rows"][1:] if diagram else block["rows"]
            result.extend(plain(cell) for row in rows for cell in row)
        else:
            raise ValueError(f"Unsupported block: {kind}")
    return result


def expected_page(page: dict) -> list[str]:
    result = [page["title"], *block_text(page["lead"])]
    for index, panel in enumerate(page["panels"]):
        result.append(panel["title"])
        result.extend(block_text(panel["blocks"], diagram=(
            (page["layout"] in {"flow", "hub"} and index == 0)
            or (page["layout"] == "edit-reveal" and index < 2)
        )))
    return result


def relative_luminance(color: str) -> float:
    values = [int(color[index:index + 2], 16) / 255 for index in (1, 3, 5)]
    linear = [x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4 for x in values]
    return sum(x * weight for x, weight in zip(linear, (0.2126, 0.7152, 0.0722), strict=True))


def contrast(first: str, second: str) -> float:
    a, b = sorted((relative_luminance(first), relative_luminance(second)))
    return (b + 0.05) / (a + 0.05)


def collect_urls(value: object) -> set[str]:
    if isinstance(value, dict):
        found = {value["url"]} if value.get("kind") == "link" else set()
        return found.union(*(collect_urls(item) for item in value.values()))
    if isinstance(value, list):
        return set().union(*(collect_urls(item) for item in value))
    return set()


def verify() -> dict:
    data = json.loads((ROOT / "typeset/workbook.json").read_text())
    tokens = json.loads((ROOT / "workbook-tokens.json").read_text())
    book = json.loads((ROOT / "book.json").read_text())
    qc = ROOT / "qc"
    qc.mkdir(exist_ok=True)
    candidate = qc / "candidate.pdf"
    draft = pymupdf.open(ROOT / "draft/book.pdf")
    draft.set_pagelayout("TwoPageRight")
    draft.save(candidate, garbage=4, deflate=True)
    draft.close()
    doc = pymupdf.open(candidate)
    failures = []
    expected = [(3, data["front"]["pages"][0] | {"layout": "flow"})]
    chapter_pages = []
    physical = 5
    for chapter in data["chapters"]:
        chapter_pages.append(physical)
        expected.extend((physical + offset + 1, page) for offset, page in enumerate(chapter["pages"]))
        physical += len(chapter["pages"]) + 1
    expected.extend((physical + index, page) for index, page in enumerate(data["sources"]["pages"]))
    art = json.loads((ROOT / "art.json").read_text())
    image_pages = {1, *chapter_pages, *(number for number, spec in expected if spec["layout"] in art["examples"])}
    if len(doc) != physical + len(data["sources"]["pages"]):
        failures.append("Page count differs from page plan")

    page_texts = [page.get_text() for page in doc]
    all_text = "\n".join(page_texts)
    coverage_count = 0
    for page_number, spec in expected:
        observed = normalized(page_texts[page_number - 1])
        for passage in expected_page(spec):
            coverage_count += 1
            if normalized(passage) not in observed:
                failures.append({"page": page_number, "missing_text": passage})

    font_sizes = Counter()
    font_details = {}
    overlaps = []
    out_of_bounds = []
    raster_pages = []
    image_failures = []
    for number, page in enumerate(doc, start=1):
        if abs(page.rect.width / MM - 210) > 0.05 or abs(page.rect.height / MM - 170) > 0.05:
            failures.append({"page": number, "size": list(page.rect)})
        lines = []
        for block in page.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                spans = line["spans"]
                text = "".join(span["text"] for span in spans)
                if not text.strip():
                    continue
                bounds = pymupdf.Rect(line["bbox"])
                if not (page.rect + (-0.5, -0.5, 0.5, 0.5)).contains(bounds):
                    out_of_bounds.append({"page": number, "text": text, "bbox": list(bounds)})
                lines.append((bounds, text))
                for span in spans:
                    font_sizes[round(span["size"], 2)] += len(span["text"].strip())
        for index, (a, text_a) in enumerate(lines):
            for b, text_b in lines[index + 1:]:
                intersection = a & b
                if intersection.is_empty:
                    continue
                if intersection.width > min(a.width, b.width) * 0.12 and intersection.height > min(a.height, b.height) * 0.30:
                    overlaps.append({"page": number, "a": text_a, "b": text_b})
        for font in page.get_fonts():
            xref, extension, kind, base, resource, encoding = font[:6]
            if xref not in font_details:
                extracted = doc.extract_font(xref)
                font_details[xref] = {"name": base, "type": kind, "bytes": len(extracted[3])}
        images = page.get_image_info()
        if images:
            raster_pages.append(number)
        if len(images) != (1 if number in image_pages else 0):
            image_failures.append({"page": number, "expected": int(number in image_pages), "observed": len(images)})

    if out_of_bounds:
        failures.append({"out_of_bounds": out_of_bounds})
    if overlaps:
        failures.append({"overlaps": overlaps})
    if image_failures:
        failures.append({"image_role_contract": image_failures})
    if any(font["bytes"] == 0 or font["type"] == "Type3" for font in font_details.values()):
        failures.append("Unembedded font or Type3 font found")
    for forbidden in ("공식 확인", "강의 근거", "\ufffd", "\x00"):
        if forbidden in all_text:
            failures.append(f"Unexpected text: {forbidden!r}")

    normalized_book = normalized(all_text)
    required = [
        "개인 맞춤 지침보다 우선한다", "개인의 저장 메모리와 프로젝트 밖 대화는 참고하지 않는다",
        "공유 프로젝트에는 프로젝트 전용 메모리가 적용된다", "내용을 미리 동기화해 두는 방식이 아니다",
        "개인 계정은 2026년 11월", "업무 계정은 2027년 3월", "교육 계정은 2027년 6월부터",
        "프로젝트 안에서 만든 작업은 업로드 파일·프로젝트 파일에 접근하지 못한다",
        "응답을 미리 준비하므로", "채팅 예약과 별도 기능이다", "Drive 소스는 자동 동기화되며",
        "PC에서 올린 사본은", "HTML 웹주소는 본문 텍스트", "자막이 있는 공개 영상",
        "말소리 없는 연주 녹음은 지원하지 않는다", "교육용 가상 공연", "담당 역할은 편집자가 제안한",
    ]
    for condition in required:
        if normalized(condition) not in normalized_book:
            failures.append({"missing_condition": condition})

    toc_links = [link for link in doc[3].get_links() if link["kind"] in (1, 4)]
    if [link["page"] + 1 for link in toc_links] != chapter_pages:
        failures.append("TOC internal link destinations differ from chapter pages")
    toc_printed_pages = []
    for index, expected_number in enumerate(chapter_pages):
        clip = pymupdf.Rect(177 * MM, (43 + index * 17) * MM, 195 * MM, (58 + index * 17) * MM)
        observed = doc[3].get_text(clip=clip).strip()
        toc_printed_pages.append(observed)
        if observed != str(expected_number):
            failures.append({"toc_printed_number": observed, "expected": expected_number})
    bookmarks = [row for row in doc.get_toc() if row[0] == 1 and row[1] in {ch["title"] for ch in data["chapters"]}]
    if [row[2] for row in bookmarks] != chapter_pages:
        failures.append("Chapter bookmarks differ from page plan")
    expected_urls = collect_urls(data) | {book["website"]}
    actual_urls = {link["uri"] for page in doc for link in page.get_links() if link["kind"] == 2}
    if not expected_urls.issubset(actual_urls):
        failures.append({"missing_links": sorted(expected_urls - actual_urls)})
    prompt_page = next(number for number, spec in expected if spec["title"] == "바로 써 보는 사전 소개문 요청")
    if "자료 '01_공연사실표.txt'와 '02_편집메모.txt'만" not in page_texts[prompt_page - 1]:
        failures.append("Copyable prompt spaces are missing")
    ratios = {"body/paper": contrast(tokens["ink"], tokens["paper"]), "muted/paper": contrast(tokens["muted"], tokens["paper"])}
    for color in {chapter["color"] for chapter in tokens["chapters"]} | {"#AD302A"}:
        ratios[f"{color}/paper"] = contrast(color, tokens["paper"])
        ratios[f"white/{color}"] = contrast("#FFFFFF", color)
        tint = "#" + "".join(f"{round(int(color[i:i + 2], 16) * 0.09 + 255 * 0.91):02x}" for i in (1, 3, 5))
        ratios[f"{color}/tint_9pct"] = contrast(color, tint)
    if min(ratios.values()) < 4.5:
        failures.append({"contrast_below_4.5": ratios})
    result = {
        "status": "PASS" if not failures else "FAIL",
        "profile": "V13 illustrated workbook; images required only on declared illustration/example pages",
        "pages": len(doc), "trim_mm": [210, 170], "page_layout": doc.pagelayout,
        "manuscript_passages_checked": coverage_count,
        "retained_conditions_checked": len(required),
        "toc_pages": chapter_pages, "toc_printed_pages": toc_printed_pages,
        "unique_external_links": len(actual_urls), "fonts": list(font_details.values()),
        "font_size_glyph_counts": dict(sorted(font_sizes.items())),
        "contrast_ratios": {key: round(value, 2) for key, value in ratios.items()},
        "out_of_bounds": out_of_bounds, "overlaps": overlaps,
        "raster_image_pages": raster_pages, "expected_image_pages": sorted(image_pages),
        "worksheet_pages": [number for number, spec in expected if spec["layout"] == "worksheet"],
        "cover_image_sha256": hashlib.sha256((ROOT / "assets/cover-openbook-v03.png").read_bytes()).hexdigest(),
        "pdf_sha256": hashlib.sha256(candidate.read_bytes()).hexdigest(),
        "failures": failures,
    }
    (qc / "workbook-report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    doc.close()
    if failures:
        raise SystemExit(json.dumps({"status": "FAIL", "failures": failures}, ensure_ascii=False))
    final = ROOT / "final"
    final.mkdir(exist_ok=True)
    (final / "book.pdf").write_bytes(candidate.read_bytes())
    print(json.dumps({"status": "PASS", "pages": result["pages"], "passages": coverage_count, "links": len(actual_urls), "overlaps": 0}, ensure_ascii=False))
    return result


if __name__ == "__main__":
    verify()
