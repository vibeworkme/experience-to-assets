#let wire(paths, c) = {
  let drawing = paths.map(d => "<path d='" + d + "' marker-end='url(#head)'/>").join("")
  place(top + left, image(bytes("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 210 170'><defs><marker id='head' markerWidth='5' markerHeight='5' refX='4.5' refY='2.5' orient='auto' markerUnits='userSpaceOnUse'><path d='M0 0L5 2.5L0 5Z' fill='" + c.to-hex() + "'/></marker></defs><g fill='none' stroke='" + c.to-hex() + "' stroke-width='.55' stroke-linejoin='round'>" + drawing + "</g></svg>"), width: 210mm, height: 170mm))
}

#let plate(H, c, pos, part, paper: false, size: 10.5pt) = {
  let (x, y, w, h) = pos.map(n => n * 1mm)
  place(top + left, dx: x, dy: y, rect(width: w, height: h,
    fill: if paper { H.paper } else { c.transparentize(94%) },
    stroke: if paper { 0.6pt + H.rule } else { none }, radius: if paper { 0mm } else { 2mm }))
  if paper { place(top + left, dx: x, dy: y, line(length: w, stroke: 1.4pt + c)) }
  (H.at)(x + 4mm, y + 4mm, w - 8mm, h - 8mm, {
    set text(size: size)
    set par(leading: 5.8pt)
    block(below: 2mm, text(size: 10pt, weight: "bold", fill: c, part.title))
    (H.content)(part.blocks, c)
  }, name: part.title)
}

#let lead(H, p, c) = (H.at)(16mm, 43mm, 178mm, 7mm, {
  set text(size: 9.5pt, fill: H.muted)
  set par(leading: 5pt)
  (H.content)(p.lead, c)
}, name: "visual lead")

#let transform(p, c, H) = {
  lead(H, p, c)
  wire(("M71 75H82", "M99 95V106", "M116 123H127V76H135", "M127 123H135"), c)
  plate(H, c, (16, 53, 55, 94), p.panels.at(0), paper: true)
  plate(H, c, (82, 60, 34, 35), p.panels.at(1))
  plate(H, c, (82, 107, 34, 35), p.panels.at(2))
  plate(H, c, (136, 53, 58, 45), p.panels.at(3), paper: true)
  plate(H, c, (136, 106, 58, 41), p.panels.at(4), paper: true)
}

#let prompt-map(p, c, H) = {
  lead(H, p, c)
  for (i, part) in p.panels.enumerate() {
    let y = 53mm + i * 24mm
    place(top + left, dx: 16mm, dy: y, rect(width: 30mm, height: 20mm, fill: c, stroke: none))
    (H.at)(19mm, y + 3mm, 24mm, 15mm, {
      let labels = part.title.split(" · ")
      text(font: "Geist Mono", size: 11pt, fill: white, labels.first())
      v(2mm)
      text(size: 10.5pt, weight: "bold", fill: white, labels.last())
    })
    place(top + left, dx: 49mm, dy: y, rect(width: 96mm, height: 20mm, fill: c.transparentize(94%), stroke: none))
    (H.at)(52mm, y + 3mm, 90mm, 15mm, {
      set text(size: 10.5pt)
      set par(leading: 5.5pt)
      (H.rich)(part.blocks.first().text)
    }, name: part.title + " quote")
    wire(("M146 " + str(63 + i * 24) + "H155",), c)
    (H.at)(160mm, y + 2mm, 34mm, 18mm, {
      set text(size: 10pt, fill: c)
      set par(leading: 5pt)
      (H.rich)(part.blocks.last().text)
    }, name: part.title + " annotation")
  }
}

#let workspace-map(p, c, H) = {
  lead(H, p, c)
  place(top + left, dx: 16mm, dy: 52mm, rect(width: 178mm, height: 99mm, stroke: 0.8pt + c, fill: none, radius: 3mm))
  (H.at)(23mm, 56mm, 110mm, 6mm, text(size: 12pt, weight: "bold", fill: c, p.panels.first().title))
  wire(("M71 100H86", "M143 80H135V93H129", "M143 122H135V105H129"), c)
  plate(H, c, (23, 69, 48, 65), p.panels.at(1), paper: true)
  plate(H, c, (143, 67, 44, 32), p.panels.at(2))
  plate(H, c, (143, 106, 44, 39), p.panels.at(3))
  place(top + left, dx: 86mm, dy: 86mm, ellipse(width: 43mm, height: 26mm, fill: c, stroke: none))
  (H.at)(92mm, 92mm, 31mm, 15mm, {
    set text(size: 11pt, weight: "bold", fill: white)
    set par(leading: 5pt)
    align(center, {
      let phrases = p.panels.first().blocks.first().text.first().text.split(" / ")
      for (i, phrase) in phrases.enumerate() {
        if i > 0 { linebreak() }
        text(phrase)
      }
    })
  }, name: "workspace center")
}

#let feedback-loop(p, c, H) = {
  lead(H, p, c)
  wire(("M64 69H81", "M129 69H146", "M170 84V112", "M146 130H80", "M40 112V84"), c)
  let positions = ((16, 53, 48, 31), (81, 53, 48, 31), (146, 53, 48, 31), (146, 112, 48, 36), (16, 112, 64, 36))
  for (i, part) in p.panels.enumerate() { plate(H, c, positions.at(i), part) }
  (H.at)(62mm, 92mm, 86mm, 13mm, align(center,
    text(font: "Paperlogy 7", size: 15pt, fill: c, "사실은 자료로, 규칙은 지침으로")))
}

#let evidence-map(p, c, H) = {
  lead(H, p, c)
  let red = rgb("#AD302A")
  (H.at)(16mm, 53mm, 66mm, 5mm, text(size: 9.5pt, weight: "bold", fill: red, "검토 대상 문장"))
  (H.at)(126mm, 53mm, 68mm, 5mm, text(size: 9.5pt, weight: "bold", fill: c, "대조할 원자료"))
  wire(("M82 74H125", "M82 104H125", "M82 134H125", "M82 134H120V111H125"), c)
  for (i, part) in p.panels.enumerate() {
    let y = 60mm + i * 30mm
    plate(H, red, (16, 60 + i * 30, 66, 25),
      (title: part.title, blocks: (part.blocks.at(0),)), paper: true)
    place(top + left, dx: 126mm, dy: y, rect(width: 68mm, height: 25mm, fill: c.transparentize(94%), stroke: none))
    (H.at)(130mm, y + 5mm, 60mm, 18mm, {
      set text(size: 11pt)
      set par(leading: 5.8pt)
      (H.rich)(part.blocks.at(1).text)
    }, name: part.title + " evidence")
    (H.at)(85mm, y, 30mm, 10mm, {
      set text(size: 9.5pt, weight: "bold", fill: c)
      set par(leading: 4.5pt)
      align(center, (H.rich)(part.blocks.at(2).text))
    }, name: part.title + " judgment")
  }
}

#let edit-reveal(p, c, H) = {
  lead(H, p, c)
  let red = rgb("#AD302A")
  (H.at)(16mm, 53mm, 178mm, 6mm, text(size: 11pt, weight: "bold", p.panels.first().title))
  let rows = p.panels.first().blocks.first().rows.slice(1)
  let xs = (16mm, 49mm, 117mm, 156mm)
  let widths = (31mm, 66mm, 37mm, 38mm)
  for (i, row) in rows.enumerate() {
    let color = if i == 0 { c } else { red }
    place(top + left, dx: xs.at(i), dy: 62mm, rect(width: widths.at(i), height: 22mm, fill: color.transparentize(93%), stroke: none))
    (H.at)(xs.at(i) + 2mm, 64mm, widths.at(i) - 4mm, 16mm, {
      set text(size: 11pt, fill: color)
      set par(leading: 5.5pt)
      if i == 0 { (H.rich)(row.first()) } else { strike((H.rich)(row.first())) }
      v(1.5mm)
      text(size: 9pt, weight: "bold", [#if i > 0 { str(i) + " · " }#(H.rich)(row.last())])
    }, name: "edit fragment " + str(i))
  }
  (H.at)(16mm, 88mm, 178mm, 5mm, text(size: 10pt, weight: "bold", fill: red, p.panels.at(1).title))
  let reasons = p.panels.at(1).blocks.first().rows.slice(1)
  for (i, row) in reasons.enumerate() {
    (H.at)(16mm + i * 60mm, 96mm, 55mm, 13mm, {
      set text(size: 10.5pt)
      set par(leading: 5.5pt)
      text(weight: "bold", fill: red, (H.rich)(row.first()))
      h(2mm)
      (H.rich)(row.last())
    }, name: "edit reason " + str(i))
  }
  plate(H, c, (16, 115, 116, 36), p.panels.at(2), paper: true, size: 11pt)
  plate(H, c, (140, 115, 54, 36), p.panels.at(3))
}

#let render-visual(p, c, H) = {
  let renderer = (transform: transform, "prompt-map": prompt-map,
    "workspace-map": workspace-map, "feedback-loop": feedback-loop,
    "evidence-map": evidence-map, "edit-reveal": edit-reveal).at(p.layout)
  renderer(p, c, H)
}
