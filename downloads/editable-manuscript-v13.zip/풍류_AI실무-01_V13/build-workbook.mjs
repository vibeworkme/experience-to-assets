import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { exportPractice } from './export-practice.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const config = JSON.parse(await readFile(path.join(root, 'pages.json'), 'utf8'));
const inline = value => {
  const parts = [];
  const pattern = /\*\*(.+?)\*\*|\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g;
  let start = 0;
  for (const match of value.matchAll(pattern)) {
    if (match.index > start) parts.push({ kind: 'text', text: value.slice(start, match.index) });
    parts.push(match[1] ? { kind: 'strong', text: match[1] } : { kind: 'link', text: match[2], url: match[3] });
    start = match.index + match[0].length;
  }
  if (start < value.length) parts.push({ kind: 'text', text: value.slice(start) });
  return parts;
};

function blocks(lines) {
  const result = [];
  for (let i = 0; i < lines.length;) {
    const line = lines[i].trim();
    if (!line) { i++; continue; }
    if (line.startsWith('::: ')) {
      const [kind, ...title] = line.slice(4).split(' ');
      let end = i + 1;
      while (end < lines.length && lines[end].trim() !== ':::') end++;
      if (end === lines.length) throw new Error('Unclosed callout');
      result.push({ kind: 'callout', tone: kind, title: inline(title.join(' ')), blocks: blocks(lines.slice(i + 1, end)) });
      i = end + 1;
    } else if (line.startsWith('|')) {
      const rows = [];
      while (i < lines.length && lines[i].trim().startsWith('|')) {
        if (!/^\|\s*---/.test(lines[i].trim())) rows.push(lines[i].trim().slice(1, -1).split('|').map(x => inline(x.trim())));
        i++;
      }
      if (!rows.length || rows.some(row => row.length !== rows[0].length)) throw new Error('Malformed table');
      result.push({ kind: 'table', rows });
    } else if (line.startsWith('- ')) {
      const items = [];
      while (i < lines.length && lines[i].trim().startsWith('- ')) items.push(inline(lines[i++].trim().slice(2)));
      result.push({ kind: 'list', items });
    } else {
      const paragraph = [];
      while (i < lines.length && lines[i].trim() && !/^(:::|\||- )/.test(lines[i].trim())) paragraph.push(lines[i++].trim());
      result.push({ kind: 'p', text: inline(paragraph.join(' ')) });
    }
  }
  return result;
}

function parse(source) {
  const lines = source.split('\n');
  if (!lines[0].startsWith('# ')) throw new Error('Missing chapter title');
  const pages = [];
  let page;
  let panel;
  let pending = [];
  const flush = () => {
    if (panel) panel.blocks = blocks(pending);
    else if (page) page.lead = blocks(pending);
    else if (pending.some(x => x.trim())) throw new Error('Content before first page');
    pending = [];
  };
  for (const line of lines.slice(1)) {
    if (line.startsWith('## ')) {
      flush();
      page = { title: line.slice(3), lead: [], panels: [] };
      panel = undefined;
      pages.push(page);
    } else if (line.startsWith('### ')) {
      flush();
      if (!page) throw new Error('Panel before page');
      panel = { title: line.slice(4), blocks: [] };
      page.panels.push(panel);
    } else pending.push(line);
  }
  flush();
  return { title: lines[0].slice(2), pages };
}

const chapters = [];
const manuscripts = [];
for (const item of config.chapters) {
  const source = await readFile(path.join(root, 'chapters', item.file), 'utf8');
  const chapter = parse(source);
  if (chapter.pages.length !== item.layouts.length) throw new Error(`Page plan mismatch: ${item.file}`);
  chapter.pages.forEach((page, index) => { page.layout = item.layouts[index]; });
  chapters.push({ ...item, ...chapter });
  manuscripts.push(source);
}
const frontText = await readFile(path.join(root, 'chapters/front.md'), 'utf8');
const front = parse(frontText);
const sourcesText = await readFile(path.join(root, 'chapters/sources.md'), 'utf8');
const sources = parse(sourcesText);
sources.pages.forEach((page, index) => { page.layout = config.sources.layouts[index]; });
const data = { chapters, front, sources };
await mkdir(path.join(root, 'typeset'), { recursive: true });
await mkdir(path.join(root, 'draft'), { recursive: true });
await writeFile(path.join(root, 'typeset/workbook.json'), JSON.stringify(data, null, 2));
const completeManuscript = [frontText, ...manuscripts, sourcesText].join('\n\n');
await writeFile(path.join(root, 'MANUSCRIPT-V13.md'), completeManuscript);
await writeFile(path.join(root, 'MANUSCRIPT-V13.txt'), completeManuscript.replace(/\*\*/g, ''));
await exportPractice(root, data);
execFileSync('typst', ['compile', '--root', root, '--font-path', path.join(root, 'fonts/v04'), '--ignore-system-fonts', path.join(root, 'workbook.typ'), path.join(root, 'draft/book.pdf')], { stdio: 'inherit' });
console.log(`Built ${chapters.reduce((n, c) => n + c.pages.length + 1, 0) + 7} pages; native text and vector diagrams.`);
