import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

const plain = parts => parts.map(part => part.kind === 'link' ? `${part.text} (${part.url})` : part.text).join('');
const csv = value => `"${value.replaceAll('"', '""')}"`;

function blocksText(blocks) {
  return blocks.map(block => {
    if (block.kind === 'p') return plain(block.text);
    if (block.kind === 'list') return block.items.map(item => `- ${plain(item)}`).join('\n');
    if (block.kind === 'table') return block.rows.map(row => row.map(plain).join(' / ')).join('\n');
    if (block.kind === 'callout') return `${plain(block.title)}\n${blocksText(block.blocks)}`;
    throw new Error(`Unknown practice block: ${block.kind}`);
  }).join('\n\n');
}

const pageText = page => [page.title, blocksText(page.lead), ...page.panels.map(panel => `${panel.title}\n${blocksText(panel.blocks)}`)].filter(Boolean).join('\n\n');

export async function exportPractice(root, data) {
  const directory = path.join(root, 'practice');
  await mkdir(directory, { recursive: true });
  const page = title => {
    const found = data.chapters.flatMap(chapter => chapter.pages).find(item => item.title === title);
    if (!found) throw new Error(`Missing practice page: ${title}`);
    return found;
  };
  const files = {
    '00_실습안내.txt': [
      '풍류 AI실무 -01 · V13 일러스트 실무판 실습자료',
      '교육용 가상 공연: 바람의 결 / 기준일: 2026-10-17',
      '01 사실표와 02 편집 메모를 먼저 읽는다. 03 요청문으로 초안을 만든 뒤 04 오류 초안을 05 수정표와 대조하고 06 완성 문서로 마무리한다. 07은 도구별 조작 안내다.',
      '오류 초안과 완성 문서는 편집자가 만든 교육용 예시이며 실제 서비스 응답이나 확정된 공연 공지가 아니다. 실제 작업에서는 가상 설정을 자신의 확정 자료로 교체한다.',
      '책의 작성 페이지 6곳은 인쇄하거나 PDF 주석으로 기록한다. 입력 폼은 아니다. 01~02의 F·E는 자료의 문장 식별자이며 자동 인용 번호가 아니다.',
      '08에는 도해, 09에는 문서와 홍보물 시안의 텍스트를 모았다. V12는 보존하고 별도 V13 판본으로 만들었다.',
      'https://aiwork.wilab.co.kr/',
    ].join('\n\n'),
    '03_사전소개문_요청문.txt': pageText(page('바로 써 보는 사전 소개문 요청')),
    '04_오류포함_검토연습용초안.txt': pageText(page('완성 사례 1 · 오류가 든 초안')),
    '05_수정표.csv': '\uFEFF' + page('완성 사례 2 · 수정한 이유').panels[0].blocks[0].rows.map(row => row.map(cell => csv(plain(cell))).join(',')).join('\n'),
    '06_완성문서.txt': pageText(page('완성 사례 3 · 관객용과 내부용')),
    '07_도구별실습.txt': [
      '풍류 AI실무 -01 · V13 / 도구별 실습',
      '설명용 절차이며 실제 계정에서 실행한 기록은 아니다. 계정·메뉴·업데이트 조건은 본문의 주의사항과 공식 도움말을 함께 읽는다.',
      ...['프로젝트 지침과 메모리의 범위', '따라 하기 · ChatGPT 프로젝트', 'Gem과 스킬 · 내 화면의 경로로', '시험할 역할 · 사전 소개문 점검자', '예약은 먼저 한 번 실행해 본다', '가져온 자료를 원문과 맞춘다', '따라 하기 · 인용에서 원문으로'].map(title => pageText(page(title))),
    ].join('\n\n'),
    '08_비주얼사례.txt': data.chapters.flatMap(chapter => chapter.pages).filter(item => ['transform', 'prompt-map', 'workspace-map', 'feedback-loop', 'evidence-map', 'edit-reveal'].includes(item.layout)).map(pageText).join('\n\n'),
    '09_문서와홍보물시안.txt': data.chapters.flatMap(chapter => chapter.pages).filter(item => ['materials', 'brief', 'poster', 'social'].includes(item.layout)).map(pageText).join('\n\n'),
  };
  for (const [filename, body] of Object.entries(files)) await writeFile(path.join(directory, filename), body + '\n');
}
