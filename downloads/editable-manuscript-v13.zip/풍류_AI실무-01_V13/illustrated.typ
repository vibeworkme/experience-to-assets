#let A = json("art.json")

#let picture(file, position) = {
  let (x, y, w, h) = position.map(n => n * 1mm)
  place(top + left, dx: x, dy: y, image(file, width: w, height: h, fit: "cover"))
}

#let paper(H, c, position, part) = {
  let (x, y, w, h) = position.map(n => n * 1mm)
  place(top + left, dx: x + 0.8mm, dy: y + 1mm, rect(width: w, height: h, fill: rgb("#E5E6DF"), stroke: none))
  place(top + left, dx: x, dy: y, rect(width: w, height: h, fill: white, stroke: 0.4pt + H.rule))
  (H.at)(x + 4mm, y + 4mm, w - 8mm, h - 8mm, {
    set text(size: 10.5pt)
    set par(leading: 5.8pt)
    block(below: 3mm, text(size: 11pt, weight: "bold", fill: c, part.title))
    (H.content)(part.blocks, c)
  }, name: part.title)
}

#let caption(H, p, c) = (H.at)(16mm, 43mm, 178mm, 9mm, {
  set text(size: 9.5pt, fill: H.muted)
  set par(leading: 5pt)
  (H.content)(p.lead, c)
}, name: "example caption")

#let image-note(H, c, position, part) = {
  let (x, y, w, h) = position.map(n => n * 1mm)
  (H.at)(x, y, w, h, {
    set text(size: 11pt)
    set par(leading: 6pt)
    (H.panel)(part, c)
  }, name: part.title)
}

#let materials(p, c, H) = {
  picture(A.examples.materials, (16, 43, 100, 65))
  (H.at)(16mm, 110mm, 100mm, 4mm, text(size: 7.5pt, fill: H.muted, "AI 생성 일러스트 · 가상의 자료 준비 장면"))
  image-note(H, c, (16, 120, 100, 31), p.panels.first())
  paper(H, c, (124, 43, 70, 50), p.panels.at(1))
  paper(H, c, (124, 101, 70, 50), p.panels.at(2))
  (H.at)(16mm, 154mm, 178mm, 5mm, {
    set text(size: 8pt, fill: H.muted)
    (H.content)(p.lead, c)
  }, name: "materials provenance")
}

#let brief(p, c, H) = {
  picture(A.examples.brief, (16, 43, 96, 64))
  (H.at)(16mm, 109mm, 96mm, 4mm, text(size: 7.5pt, fill: H.muted, "AI 생성 일러스트 · 가상의 문서 작업 장면"))
  image-note(H, c, (16, 120, 96, 31), p.panels.first())
  paper(H, c, (122, 43, 72, 108), p.panels.at(1))
  (H.at)(16mm, 154mm, 178mm, 5mm, {
    set text(size: 8pt, fill: H.muted)
    (H.content)(p.lead, c)
  }, name: "brief provenance")
}

#let poster(p, c, H) = {
  let copy = p.panels.first()
  place(top + left, dx: 16mm, dy: 43mm, rect(width: 80mm, height: 108mm, fill: white, stroke: 0.5pt + H.rule))
  picture(A.examples.poster, (16, 43, 80, 49))
  (H.at)(21mm, 96mm, 70mm, 13mm, text(font: "Paperlogy 7", size: 26pt, fill: rgb("#253E4D"), copy.title))
  (H.at)(21mm, 110mm, 70mm, 9mm, {
    set text(size: 11.5pt, weight: "bold", fill: c)
    set par(leading: 5pt)
    (H.rich)(copy.blocks.at(0).text)
  }, name: "poster subtitle")
  (H.at)(21mm, 121mm, 70mm, 14mm, {
    set text(size: 9.5pt)
    set par(leading: 4.5pt)
    (H.rich)(copy.blocks.at(1).text)
  }, name: "poster audience")
  (H.at)(21mm, 138mm, 70mm, 5mm, text(size: 8.5pt, fill: c, (H.rich)(copy.blocks.at(2).text)))
  (H.at)(21mm, 146mm, 70mm, 4mm, text(size: 7.5pt, fill: H.muted, (H.rich)(copy.blocks.at(3).text)))
  for (i, part) in p.panels.slice(1).enumerate() {
    image-note(H, c, (112, 43 + i * 36, 82, 32), part)
  }
  (H.at)(16mm, 154mm, 178mm, 5mm, {
    set text(size: 8pt, fill: H.muted)
    (H.content)(p.lead, c)
  }, name: "poster provenance")
}

#let social(p, c, H) = {
  let copy = p.panels.first()
  place(top + left, dx: 16mm, dy: 47mm, rect(width: 90mm, height: 90mm, fill: white, stroke: 0.5pt + H.rule))
  picture(A.examples.social, (16, 47, 90, 45))
  (H.at)(21mm, 96mm, 80mm, 10mm, text(font: "Paperlogy 7", size: 23pt, fill: rgb("#253E4D"), copy.title))
  (H.at)(21mm, 108mm, 80mm, 5mm, text(size: 10.5pt, weight: "bold", fill: c, (H.rich)(copy.blocks.at(0).text)))
  for i in range(1, 4) {
    (H.at)(21mm, (115 + (i - 1) * 7) * 1mm, 80mm, 6mm,
      text(size: if i == 3 { 7.5pt } else { 9pt }, fill: if i == 1 { H.ink } else { H.muted }, (H.rich)(copy.blocks.at(i).text)))
  }
  paper(H, c, (119, 43, 75, 108), p.panels.at(1))
  (H.at)(16mm, 143mm, 90mm, 8mm, text(size: 8pt, fill: H.muted, "AI 생성 분위기 이미지 · 교육용 가상 공연의 시안"))
  (H.at)(16mm, 154mm, 178mm, 5mm, {
    set text(size: 8pt, fill: H.muted)
    (H.content)(p.lead, c)
  }, name: "social provenance")
}

#let render-example(p, c, H) = {
  let renderer = (materials: materials, brief: brief, poster: poster, social: social).at(p.layout)
  renderer(p, c, H)
}

#let illustrated-opener(ch, H) = page(fill: H.paper, {
  show heading: set text(size: 1em)
  let c = rgb(H.T.chapters.at(ch).color)
  let chapter = H.D.chapters.at(ch)
  place(top + left, box(width: 210mm, height: 101mm, clip: true, {
    place(top + left, image(A.chapters.at(ch).file, width: 210mm, height: 140mm, fit: "contain"))
    box(width: 1pt, height: 1pt)
  }))
  (H.at)(16mm, 104mm, 178mm, 4mm, text(size: 7.5pt, fill: H.muted,
    "AI 생성 일러스트 · " + A.chapters.at(ch).scene + "를 상상한 가상 장면"))
  (H.at)(16mm, 113mm, 35mm, 6mm, text(font: "Geist Mono", size: 9pt, fill: c, "CHAPTER 0" + str(ch + 1)))
  (H.at)(54mm, 111mm, 140mm, 9mm, text(font: "Paperlogy 7", size: 16pt, fill: c, H.T.chapters.at(ch).word))
  (H.at)(16mm, 123mm, 178mm, 12mm,
    text(font: "Paperlogy 7", size: 22pt, [#heading(level: 1, chapter.title)#label("ch-" + str(ch + 1))]), name: "illustrated chapter title")
  (H.at)(16mm, 138mm, 178mm, 6mm, text(size: 10.5pt, chapter.promise))
  (H.at)(16mm, 148mm, 178mm, 10mm,
    grid(columns: (1fr, 1fr, 1fr), column-gutter: 10mm,
      ..chapter.goals.enumerate().map(((i, goal)) => {
        set text(size: 9.5pt)
        set par(leading: 4.5pt)
        text(fill: c, "0" + str(i + 1) + "  ")
        (H.rich)(((kind: "text", text: goal),))
      })), name: "illustrated chapter goals")
  (H.footer)(c)
  box(width: 1pt, height: 1pt)
})
